package model.characters;

import java.awt.Point;

import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughActionsException;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;

public  class  Zombie extends Character {
	static int ZOMBIES_COUNT = 1;
	private int speed;
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public Zombie() {
		super("Zombie " + ZOMBIES_COUNT, 40, 10);
		ZOMBIES_COUNT++;
	
	}
	
	
	public void attack() throws InvalidTargetException,NotEnoughActionsException {
	
			
			
//			if(Math.abs(getTarget().getLocation().x-this.getLocation().x)>1 || Math.abs(getTarget().getLocation().y-this.getLocation().y)>1) 
//				throw new InvalidTargetException("Can't attack non-adjacent cells.");
		int X=this.getLocation().y;
		int Y=this.getLocation().x;	
		
		for(int i=0;i<1;i++) {
		Point Right=new Point(X+1,Y);
		if(Right.x>=0&&Right.x<15) {
			if(Game.map[Right.x][Right.y] instanceof CharacterCell) {
			CharacterCell ccc= (CharacterCell)Game.map[Right.x][Right.y];
			if(ccc.getCharacter() instanceof Hero) {
				this.setTarget(ccc.getCharacter());
				
				continue;
			}}
					}
		Point Bottom=new Point(X-1,Y);
		if(Bottom.x>=0&&Bottom.x<15) {
			if(Game.map[Bottom.x][Bottom.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[Bottom.x][Bottom.y];
				if(ccc.getCharacter() instanceof Hero) {
					this.setTarget(ccc.getCharacter());
					
					continue;
				}
				
				}
			
			
			}
		Point Top=new Point(X,Y+1);
		if(Top.y>=0&&Top.y<15)
			if(Game.map[Top.x][Top.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[Top.x][Top.y];
				if(ccc.getCharacter() instanceof Hero) {
					this.setTarget(ccc.getCharacter());
					
					continue;
				}
				
				}
			
			
			
			
			
		Point Left =new Point(X,Y-1);
		if(Left.y>=0&&Left.y<15)
			if(Top.y>=0&&Top.y<15)
				if(Game.map[Left.x][Left.y] instanceof CharacterCell) {
					CharacterCell ccc= (CharacterCell)Game.map[Left.x][Left.y];
					if(ccc.getCharacter() instanceof Hero) {
						this.setTarget(ccc.getCharacter());
						
						continue;
					}
					
					}
			
			
			
			
		Point TopRight=new Point(X+1,Y+1);
		if(TopRight.y>=0&&TopRight.y<15&&TopRight.x>=0&&TopRight.x<15)
			if(Game.map[TopRight.x][TopRight.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[TopRight.x][TopRight.y];
				if(ccc.getCharacter() instanceof Hero) {
					this.setTarget(ccc.getCharacter());
					
					continue;
				}
				
				}
			
			
			
		Point TopLeft=new Point(X-1,Y+1);
		if(TopLeft.y>=0&&TopLeft.y<15&&TopLeft.x>=0&&TopLeft.x<15)
			if(Game.map[TopLeft.x][TopLeft.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[TopLeft.x][TopLeft.y];
				if(ccc.getCharacter() instanceof Hero) {
					this.setTarget(ccc.getCharacter());
					
					continue;
				}
				
				}
			
			
			
		Point BottomRight=new Point(X+1,Y-1);
		if(BottomRight.y>=0&&BottomRight.y<15 && BottomRight.x>=0&& BottomRight.x<15)
			if(Game.map[BottomRight.x][BottomRight.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[BottomRight.x][BottomRight.y];
				if(ccc.getCharacter() instanceof Hero) {
					this.setTarget(ccc.getCharacter());
				
					continue;
				}
				
				}
			
			
			
		Point BottomLeft=new Point(X-1,Y-1);
		if(BottomLeft.y>=0&&BottomLeft.y<15&&BottomLeft.x>=0&&BottomLeft.x<15)
			if(Game.map[BottomLeft.x][BottomLeft.y] instanceof CharacterCell) {
				CharacterCell ccc= (CharacterCell)Game.map[BottomLeft.x][BottomLeft.y];
				if(ccc.getCharacter() instanceof Hero) {
					this.setTarget(ccc.getCharacter());
					
					continue;
				}
				
				}
		return;
	
		
		
		}
				
		
		
		
		
		
		
		
		
		
		
		
		super.attack();
			
	}
	public void defend(Character c) {
		
	super.defend(c);
		
		
	}
	
	public void onCharacterDeath() {
		super.onCharacterDeath();
		Game.zombies.remove(this);
		
		
		int l= (int) (Math.random()*15);
		 int s= (int) (Math.random()*15);
		
		 while((l==0 && s==0)||	(l==this.getLocation().x && s==this.getLocation().y )	|| (Game.map[l][s] instanceof CollectibleCell)||(Game.map[l][s] instanceof TrapCell)) {
			  l= (int) (Math.random()*15);
			  s= (int) (Math.random()*15);
		 }
		do {
			if (Game.map[l][s] instanceof  CharacterCell) {
				CharacterCell x=(CharacterCell) Game.map[l][s];
				if((x.getCharacter() instanceof Zombie)|| (x.getCharacter() instanceof Hero)) {
					l= (int) (Math.random()*15);
					  s= (int) (Math.random()*15);
				}
				else {
					break;
				}
			}
		 }while(true);
		CharacterCell D=(CharacterCell)Game.map[l][s];
		Zombie z=new Zombie();
		D.setCharacter(z);
		Game.zombies.add(z);
		z.setLocation(new Point(l,s));
	}
	
	
	

}