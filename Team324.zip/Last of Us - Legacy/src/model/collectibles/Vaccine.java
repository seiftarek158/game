package model.collectibles;

import java.util.ArrayList;
import java.awt.Point;
import engine.Game;
import exceptions.NoAvailableResourcesException;
import model.characters.Hero;
import model.world.CharacterCell;

public class Vaccine implements Collectible {

	public Vaccine() {
		
	}

	public void pickUp(Hero h) {
		ArrayList<Vaccine> A=h.getVaccineInventory();
		
		A.add(this);
		
	}

	@Override
	public void use(Hero h) throws NoAvailableResourcesException {
		ArrayList<Vaccine> A =h.getVaccineInventory();
		if(A.isEmpty())
			throw new NoAvailableResourcesException("No available vaccines");
		A.remove(this);	
		int x=0;
		
		x= (int) (Math.random()*Game.availableHeroes.size());
		Hero z=Game.availableHeroes.get(x);
Game.heroes.add(z);
Game.availableHeroes.remove(z);
CharacterCell c=(CharacterCell)Game.map[h.getTarget().getLocation().x][h.getTarget().getLocation().y];
c.setCharacter(z);
z.setLocation(new Point(h.getTarget().getLocation().x,h.getTarget().getLocation().y));
h.setActionsAvailable(h.getActionsAvailable()-1);
		Game.zombies.remove(h.getTarget());
	}

}
