package model.collectibles;

import exceptions.*;
import model.characters.Hero;

public interface Collectible {
	public  void pickUp(Hero h)throws NoAvailableResourcesException;
	public void use(Hero h) throws NoAvailableResourcesException;
}
