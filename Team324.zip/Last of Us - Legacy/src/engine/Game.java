package engine;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import exceptions.InvalidTargetException;
import exceptions.NotEnoughActionsException;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.Cell;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;

public class Game {
	
	public static Cell [][] map=new Cell[15][15];;
	public static ArrayList <Hero> availableHeroes = new ArrayList<Hero>();
	public static ArrayList <Hero> heroes =  new ArrayList<Hero>();
	public static ArrayList <Zombie> zombies =  new ArrayList<Zombie>();
	public static ArrayList <Point> Dead=new ArrayList<Point>();
	
	
		
	public static void loadHeroes(String filePath)  throws IOException {
		
		
		BufferedReader br = new BufferedReader(new FileReader(filePath));
		String line = br.readLine();
		while (line != null) {
			String[] content = line.split(",");
			Hero hero=null;
			switch (content[1]) {
			case "FIGH":
				hero = new Fighter(content[0], Integer.parseInt(content[2]), Integer.parseInt(content[4]), Integer.parseInt(content[3]));
				break;
			case "MED":  
				hero = new Medic(content[0], Integer.parseInt(content[2]), Integer.parseInt(content[4]), Integer.parseInt(content[3])) ;
				break;
			case "EXP":  
				hero = new Explorer(content[0], Integer.parseInt(content[2]), Integer.parseInt(content[4]), Integer.parseInt(content[3]));
				break;
			}
			availableHeroes.add(hero);
			line = br.readLine();
			
			
		}
		br.close();

		
		
	}
	
	
	public static void startGame(Hero h) throws NullPointerException{
		for(int i=0;i<15;i++)
			for(int j=0;j<15;j++)
				map[i][j]=new CharacterCell(null);
		availableHeroes.remove(h);
		heroes.add(h);
		CharacterCell c1=(CharacterCell)map[0][0];
		c1.setCharacter(h);
		Point t=new Point(0,0);
		map[0][0].setVisible(true);
	    h.setLocation(t);
	    h.setSpecialAction(false);
		for(int i=0;i<5;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while(!((map[l][s] instanceof CharacterCell && ((CharacterCell) map[l][s]).getCharacter() == null) || map[l][s] == null)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			 map[l][s]=new CollectibleCell(new Supply());
			 map[l][s].setVisible(false);
			 
		}
		for(int i=0;i<5;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while(!((map[l][s] instanceof CharacterCell && ((CharacterCell) map[l][s]).getCharacter() == null) || map[l][s] == null)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			 map[l][s]=new CollectibleCell(new Vaccine());
			 map[l][s].setVisible(false);
			 
		}
		for(int i=0;i<5;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			 
			
			 while((l==0 && s==0)|| (map[l][s] instanceof CollectibleCell)||(map[l][s] instanceof TrapCell)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			 map[l][s]=new TrapCell();
			 map[l][s].setVisible(false);
			 
		}
		for(int i=0;i<10;i++) {
			 int l= (int) (Math.random()*15);
			 int s= (int) (Math.random()*15);
			
			 while(!((map[l][s] instanceof CharacterCell && ((CharacterCell) map[l][s]).getCharacter() == null) || map[l][s] == null)) {
				  l= (int) (Math.random()*15);
				  s= (int) (Math.random()*15);
			 }
			do {
				if (map[l][s] instanceof  CharacterCell) {
					CharacterCell x=(CharacterCell) map[l][s];
					if((x.getCharacter() instanceof Zombie)|| (x.getCharacter() instanceof Hero)) {
						l= (int) (Math.random()*15);
						  s= (int) (Math.random()*15);
					}
					else {
						break;
					}
				}
			 }while(true);
			CharacterCell c=(CharacterCell)map[l][s];
			Zombie z=new Zombie();
			map[l][s].setVisible(false);
			c.setCharacter(z);
			z.setLocation(new Point(l,s));
			zombies.add(z);
			 
			 
		}
		Hero.SetAdjacentVisibility(t);}
	public static boolean checkWin() {
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				if(map[i][j] instanceof CollectibleCell) {
					CollectibleCell cc=(CollectibleCell) map[i][j];
					if(cc.getCollectible() instanceof Vaccine)
						return false;
				}
					
			}
		}
		for(int i=0;i<heroes.size();i++) {
			Hero hh=heroes.get(i);
			if(!(hh.getVaccineInventory().isEmpty()))
				return false;
		}
		if(heroes.size()>=5)
			return true;
		else {
			return false;
		}
	}
	
	
	public static boolean checkGameOver() {
		if(heroes.isEmpty())
			return true;
		
		
		int x=heroes.size()+availableHeroes.size();
		
//		if(x<5) {
//			return true;
//		}
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				if(map[i][j] instanceof CollectibleCell) {
					CollectibleCell cc=(CollectibleCell) map[i][j];
					if(cc.getCollectible() instanceof Vaccine)
						return false;
				}
					
			}
		}
		for(int i=0;i<heroes.size();i++) {
			Hero hh=heroes.get(i);
			if(!(hh.getVaccineInventory().isEmpty()))
				return false;
		}
		return true;
		
	}
	public static void endTurn() throws InvalidTargetException, NotEnoughActionsException {
		//to do #1 neloop 3ala el xzombies to attack adjacent cells ✅
		//to do #2 neloop 3ala el heroes ne5ally:
//		actions available, 
//		target==null,
//		specialaction ne5alleeh befalse ,
//		set adjacent visibility of el heroes,
//		and a random zombie 
		
		for(int i=0;i<zombies.size();i++) {
			Zombie z=zombies.get(i);
			z.attack();
			
					}
				
				
				
			
					
					
				
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				if(map[i][j] instanceof CollectibleCell) {
					Point p= new Point(j,i);
					if(Dead.contains(p))
					{
						Hero.SetAdjacentVisibility(p);
					}
					else {
						map[i][j].setVisible(false);}
					
				}
					
			}
		}
		for(int i=0;i<heroes.size();i++) {
        Hero h=heroes.get(i);
        h.setActionsAvailable(h.getMaxActions());
        h.setTarget(null);
        h.setSpecialAction(false);
      
        Hero.SetAdjacentVisibility(h.getLocation());
        
        }
		
		
		int l= (int) (Math.random()*15);
		 int s= (int) (Math.random()*15);
		
		 while((l==0 && s==0)|| (Game.map[l][s] instanceof CollectibleCell)||(Game.map[l][s] instanceof TrapCell)) {
			  l= (int) (Math.random()*15);
			  s= (int) (Math.random()*15);
		 }
		do {
			if (Game.map[l][s] instanceof  CharacterCell) {
				CharacterCell x=(CharacterCell) Game.map[l][s];
				if((x.getCharacter() instanceof Zombie)|| (x.getCharacter() instanceof Hero)){
					l= (int) (Math.random()*15);
					  s= (int) (Math.random()*15);
				}
				else {
					break;
				}
			}
		 }while(true);
		CharacterCell D=(CharacterCell)Game.map[l][s];
		Zombie z=new Zombie();
		D.setCharacter(z);
		Game.zombies.add(z);
		z.setLocation(new Point(l,s));
		
		for(int i=0;i<zombies.size();i++) {
			zombies.get(i).setTarget(null);
		}
		
		
	}
	
	



}