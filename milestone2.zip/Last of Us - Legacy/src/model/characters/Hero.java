package model.characters;

import java.awt.Point;
import java.util.ArrayList;

import engine.Game;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.CharacterCell;
import model.world.*;
import exceptions.*;
public abstract class Hero extends Character {
	

		private int actionsAvailable;
		private int maxActions;
		private ArrayList<Vaccine> vaccineInventory;
		private ArrayList<Supply> supplyInventory;
		private boolean specialAction;
	
		
		public Hero(String name,int maxHp, int attackDmg, int maxActions) {
			super(name,maxHp, attackDmg);
			this.maxActions = maxActions;
			this.actionsAvailable = maxActions;
			this.vaccineInventory = new ArrayList<Vaccine>();
			this.supplyInventory=new ArrayList<Supply>();
			this.specialAction=false;
		
		}
		
		
		public void attack() throws InvalidTargetException,NotEnoughActionsException {
			if(this.getTarget()==null)
				throw new InvalidTargetException();
			if(this.getTarget() instanceof Hero)
				throw new InvalidTargetException();
			
			
			if(Math.abs(getTarget().getLocation().x-this.getLocation().x)>1 || Math.abs(getTarget().getLocation().y-this.getLocation().y)>1) 
				throw new InvalidTargetException("Can't attack non-adjacent cells.");
			if(this instanceof Hero) {
				
				Hero H =(Hero)this;
				if(!(H instanceof Fighter && H.isSpecialAction())) {
				int x=H.getActionsAvailable();
				if(x>0) {
					x-=1;
					H.setActionsAvailable(x);
				}
				else {
					throw new NotEnoughActionsException();
				}}
			}
		
		
		
			int cHp=getTarget().getCurrentHp();
			cHp-=this.getAttackDmg();
			getTarget().setCurrentHp(cHp);
			
			
				
			getTarget().defend(this);
			
		
			
		
	}
		public void defend(Character c) {
			
			setTarget(c);
			int cHp=getTarget().getCurrentHp();
			cHp-=(this.getAttackDmg()/2);
			getTarget().setCurrentHp(cHp);
			
			
		}

		
	


		public boolean isSpecialAction() {
			return specialAction;
		}



		public void setSpecialAction(boolean specialAction) {
			this.specialAction = specialAction;
		}



		public int getActionsAvailable() {
			return actionsAvailable;
		}



		public void setActionsAvailable(int actionsAvailable) {
			this.actionsAvailable = actionsAvailable;
		}



		public int getMaxActions() {
			return maxActions;
		}



		public ArrayList<Vaccine> getVaccineInventory() {
			return vaccineInventory;
		}


		public ArrayList<Supply> getSupplyInventory() {
			return supplyInventory;
		}
		public void move(Direction d) throws MovementException, NotEnoughActionsException {
			if(this.actionsAvailable==0)
    	  throw new NotEnoughActionsException("No available Actions");
			Point Q;
			switch(d) {
			case UP: if (this.getLocation().x==14)
				throw new MovementException("You Have reached the end of the map ");
				else
					 Q =new Point(this.getLocation().x+1,this.getLocation().y);break;
			case DOWN:if (this.getLocation().x==0)
				throw new MovementException("You Have reached the end of the map ");
				else
					 Q=new Point(this.getLocation().x-1,this.getLocation().y);break;
			case RIGHT:if (this.getLocation().y==14)
				throw new MovementException("You Have reached the end of the map ");
				else
					 	Q=new Point(this.getLocation().x,this.getLocation().y+1);break;
			default:if (this.getLocation().y==0)
				throw new MovementException("You Have reached the end of the map ");
				else
					 Q=new Point(this.getLocation().x,this.getLocation().y-1);break;
			}
			if(Game.map[Q.x][Q.y] instanceof CharacterCell) {
				CharacterCell m=(CharacterCell) Game.map[Q.x][Q.y];
				if(m.getCharacter()!=null)
				throw new MovementException("Cell is occupied");
				else{
					CharacterCell f=(CharacterCell) Game.map[this.getLocation().x][this.getLocation().y];
					f.setCharacter(null);
					
					
					  this.setLocation(Q);
					  
					  SetAdjacentVisibility(Q);
						this.setActionsAvailable(this.getActionsAvailable()-1);
						
						
						m.setCharacter(this);
						m.setVisible(true);
					}
				}
			
			else {
				if(Game.map[Q.x][Q.y] instanceof CollectibleCell) {
					CollectibleCell m=(CollectibleCell) Game.map[Q.x][Q.y];
					m.getCollectible().pickUp(this);
					Game.map[Q.x][Q.y]=new CharacterCell(this);
					
				}
				else if(Game.map[Q.x][Q.y] instanceof TrapCell) {
					TrapCell m=(TrapCell) Game.map[Q.x][Q.y];
					this.setCurrentHp(this.getCurrentHp()-m.getTrapDamage());
					Game.map[Q.x][Q.y]=new CharacterCell(this);
				}
				
				CharacterCell m=(CharacterCell) Game.map[this.getLocation().x][this.getLocation().y];
				m.setCharacter(null);
				
				
			  this.setLocation(Q);
			  
			  SetAdjacentVisibility(Q);
				this.setActionsAvailable(this.getActionsAvailable()-1);
				
				CharacterCell mm=(CharacterCell) Game.map[this.getLocation().x][this.getLocation().y];
				mm.setCharacter(this);
				mm.setVisible(true);
			  
			}
			
		
			
		}
		



		
public static void SetAdjacentVisibility(Point q) {
			int X=q.x;
			int Y=q.y;
			Point Right=new Point(X,Y+1);
			if(Right.y>=0&&Right.y<15)
				Game.map[Right.x][Right.y].setVisible(true);
			Point Left=new Point(X,Y-1);
			if(Left.y>=0&&Left.y<15)
				Game.map[Left.x][Left.y].setVisible(true);
			Point Top=new Point(X+1,Y);
			if(Top.x>=0&&Top.x<15)
				Game.map[Top.x][Top.y].setVisible(true);
			Point Bottom =new Point(X-1,Y);
			if(Bottom.x>=0&&Bottom.x<15)
				Game.map[Bottom.x][Bottom.y].setVisible(true);
			Point TopRight=new Point(X+1,Y+1);
			if(TopRight.y>=0&&TopRight.y<15&&TopRight.x>=0&&TopRight.x<15)
				Game.map[TopRight.x][TopRight.y].setVisible(true);
			Point TopLeft=new Point(X+1,Y-1);
			if(TopLeft.y>=0&&TopLeft.y<15&&TopLeft.x>=0&&TopLeft.x<15)
				Game.map[TopLeft.x][TopLeft.y].setVisible(true);
			Point BottomRight=new Point(X-1,Y+1);
			if(BottomRight.y>=0&&BottomRight.y<15 && BottomRight.x>=0&& BottomRight.x<15)
				Game.map[BottomRight.x][BottomRight.y].setVisible(true);
			Point BottomLeft=new Point(X-1,Y-1);
			if(BottomLeft.y>=0&&BottomLeft.y<15&&BottomLeft.x>=0&&BottomLeft.x<15)
				Game.map[BottomLeft.x][BottomLeft.y].setVisible(true);
			
		}





public void useSpecial() throws  NoAvailableResourcesException,NotEnoughActionsException, InvalidTargetException{
	if(supplyInventory.isEmpty()) {
		throw new NoAvailableResourcesException("There is no Supply available!!");
		
	}
	if(specialAction)
		throw new NotEnoughActionsException("You have used your special action before!!");
	Hero h=(Hero) this;
	setSpecialAction(true);
	
	
	 if(h instanceof Explorer) {
			
		for(int i=0;i<15;i++) {
			for(int j=0;j<15;j++) {
				Game.map[i][j].setVisible(true);
			}
		}
	}
	else if(h instanceof Medic) {
		Hero k=this;
		//el mafrood hero k dah yheal nafso aw yheal other heroes
		
		
		k.setCurrentHp(k.getMaxHp());
		
	}
		
	supplyInventory.remove(0);
	
	
	
}

public void cure() throws NoAvailableResourcesException,InvalidTargetException {
	if(vaccineInventory.isEmpty()) {
		throw new NoAvailableResourcesException("There is no Vaccine available!!");
		
		
	}
	if(this.getTarget() instanceof Hero) {
		throw new InvalidTargetException("Cannot cure a hero to hero!");
	}
	if(this.getTarget() instanceof Zombie) {
		
		if(Math.abs(getTarget().getLocation().x-this.getLocation().x)>1 || Math.abs(getTarget().getLocation().y-this.getLocation().y)>1) 
			throw new InvalidTargetException("Zombie is not in adjacent Cell!!");
		
		
		int x=0;
		
			x= (int) (Math.random()*Game.availableHeroes.size());
			Hero z=Game.availableHeroes.get(x);
	Game.heroes.add(z);
	Game.availableHeroes.remove(z);
	Game.zombies.remove(this.getTarget() );
	this.getVaccineInventory().get(0).use(this);
	//this.getVaccineInventory().remove(0);
	CharacterCell c=(CharacterCell)Game.map[this.getTarget().getLocation().x][this.getTarget().getLocation().y];
	c.setCharacter(z);
	
	}
	
}


}