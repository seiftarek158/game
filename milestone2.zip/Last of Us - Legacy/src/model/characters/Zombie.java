package model.characters;

import exceptions.InvalidTargetException;
import exceptions.NotEnoughActionsException;

public  class  Zombie extends Character {
	static int ZOMBIES_COUNT = 1;
	private int speed;
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public Zombie() {
		super("Zombie " + ZOMBIES_COUNT, 40, 10);
		ZOMBIES_COUNT++;
	
	}
	
	
	public void attack() throws InvalidTargetException,NotEnoughActionsException {
		if(this.getTarget()==null)
			throw new InvalidTargetException();
			
			if(this instanceof Zombie && this.getTarget() instanceof Zombie)
				throw new InvalidTargetException();
			if(Math.abs(getTarget().getLocation().x-this.getLocation().x)>1 || Math.abs(getTarget().getLocation().y-this.getLocation().y)>1) 
				throw new InvalidTargetException("Can't attack non-adjacent cells.");
			
		
		
		
			int cHp=getTarget().getCurrentHp();
			cHp-=this.getAttackDmg();
			getTarget().setCurrentHp(cHp);
			
			
				
			getTarget().defend(this);
			
	}
	public void defend(Character c) {
		
		setTarget(c);
		int cHp=getTarget().getCurrentHp();
		cHp-=(this.getAttackDmg()/2);
		getTarget().setCurrentHp(cHp);
		
		
	}

}