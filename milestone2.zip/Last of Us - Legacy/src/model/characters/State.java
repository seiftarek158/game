package model.characters;

public enum State {
	STALKER,
	CLICKER;

}
