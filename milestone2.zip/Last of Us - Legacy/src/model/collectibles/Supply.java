package model.collectibles;

import java.util.ArrayList;

import model.characters.Hero;
import exceptions.*;

public class Supply implements Collectible  {

	

	
	public Supply() {
		
	}
	public void pickUp(Hero h) {
		ArrayList<Supply> a = h.getSupplyInventory();
		a.add(this);
	}
	public void use(Hero h) throws NoAvailableResourcesException{
		
		ArrayList<Supply> a = h.getSupplyInventory();
		
		if(a.isEmpty()) {
			throw new NoAvailableResourcesException("No Resources Available!");
		}
		else {
		a.remove(this);}
	}
	


	
		
		

}
