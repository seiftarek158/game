package model.collectibles;

import java.util.ArrayList;

import exceptions.NoAvailableResourcesException;
import model.characters.Hero;

public class Vaccine implements Collectible {

	public Vaccine() {
		
	}
	public void pickUp(Hero h) {
		ArrayList<Vaccine> a = h.getVaccineInventory();
		a.add(this);
	}
	public void use(Hero h)throws NoAvailableResourcesException {
		ArrayList<Vaccine> a = h.getVaccineInventory();
		if(a.isEmpty()) {
			throw new NoAvailableResourcesException("No Resources Available!");
		}
		else {
		a.remove(this);}
		
	}

}
